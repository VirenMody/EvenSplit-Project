Hello

1) First run the BuildEvenSplit console app to build the database. 
   I couldn't figure out how to drop procedures without running into errors.
   So I deleted the procedures before submitting so that when you run the app
   it'll create the stored procedures.
   That discussion is @235 on piazza.

2) EvenSplitApp is the GUI for the program

3) Login info for the program:
   Email: just use any uic email... but test atleast mine: vmody2@uic.edu which has data
   Password: its first name with CS480 i.e. VirenCS480