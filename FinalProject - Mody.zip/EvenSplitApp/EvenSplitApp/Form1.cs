﻿// 
// Multi-user GUI app to simulate tracking of
// shared expenses amongst a group of people
// and evenly split the cost amongst each member.
// It uses exception handling, transactions, and
// query batching to be more efficient and tolerant
// of multi-user, real-world usage.
//
// Viren Mody
// U. of Illinois, Chicago
// CS480, Summer 2016
// Final Project
//

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data.SqlClient;

namespace EvenSplitApp
{
	public partial class Form1 : Form
	{
		SqlTransaction tx;

		//
		// remote Azure cloud connection info:
		//
		//string NetID = "vmody2";
		//string databasename = "EvenSplitDB";
		//string username = "vmody2";
		//string pwd = "VirenCS480";
		public static string connectionInfo = string.Format(@"
Server=tcp:vmody2.database.windows.net,1433;Initial Catalog=EvenSplitDB;Persist Security Info=False;User ID=vmody2;Password=VirenCS480;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;
");
		public static string login;

		// #####################################################
		//
		// Helper functions:
		//

		/// <summary>
		/// Executes the given SQL string, which should be an "action" such as 
		/// create table, drop table, insert, update, or delete.  Returns 
		/// normally if successful, throws an exception if not.
		/// </summary>
		/// <param name="sql">query to execute</param>
		static void ExecuteActionQuery(SqlConnection db, string sql)
		{
			SqlCommand cmd = new SqlCommand();
			cmd.Connection = db;
			cmd.CommandText = sql;

			cmd.ExecuteNonQuery();
		}

		static object ExecuteScalarQuery(SqlConnection db, string sql)
		{
			object result;
			SqlCommand cmd = new SqlCommand();
			cmd.Connection = db;
			cmd.CommandText = sql;
			result = cmd.ExecuteScalar();
			return result;
		}

		public static DataSet ExecuteNonScalarQuery(SqlConnection db, string sql)
		{
			DataSet ds = new DataSet();
			SqlCommand cmd = new SqlCommand();
			cmd.Connection = db;
			SqlDataAdapter adapter = new SqlDataAdapter(cmd);
			cmd.CommandText = sql;

			adapter.Fill(ds);
			return ds;
		}

		private void ClearExpenseDetailsUI()
		{
			//Clear Expense Details
			txtGroupTotalExpense.Clear();
			txtGroupTotalExpense.Refresh();

			txtExpenseID.Clear();
			txtExpenseID.Refresh();
			lstUserEmails.ResetText();
			lstUserEmails.Items.Clear();
			lstUserEmails.Refresh();
			txtGroupName.Clear();
			txtGroupName.Refresh();
			lstCategories.ResetText();
			lstCategories.Items.Clear();
			lstCategories.Refresh();
			txtDescription.Clear();
			txtDescription.Refresh();
			txtCost.Clear();
			txtCost.Refresh();
			txtDate.Clear();
			txtDate.Refresh();
		}

		private void ClearUI()
		{
			ClearExpenseDetailsUI();

			// Clear Group Expenses
			lstGroupExpenses.Items.Clear();
			lstGroupExpenses.Refresh();

			// Clear Members
			lstMembers.Items.Clear();
			lstMembers.Items.Clear();

			// Clear Groups
			lstGroups.Items.Clear();
			lstGroups.Refresh();
		}

		public string getGroupName()
		{
			// Get the selected group and pull out name
			string selection = this.lstGroups.SelectedItem.ToString();
			int pos = selection.IndexOf(':');
			string groupName = (selection.Substring(0, pos));

			return groupName;
		}



		public Form1()
		{
			InitializeComponent();
		}

		// #####################################################
		//
		// UI event handlers:
		//

		private void Form1_Load(object sender, EventArgs e)
		{
			SqlConnection db = null;
			string sql;

			try
			{
				//
				// Load categories list
				//

				db = new SqlConnection(connectionInfo);
				db.Open();

				sql = string.Format(@"
SELECT Category
FROM ExpenseCategories
ORDER BY Category ASC;
");

				DataSet ds = ExecuteNonScalarQuery(db, sql);

				foreach (DataRow row in ds.Tables["TABLE"].Rows)
				{
					this.lstCategories.Items.Add(Convert.ToString(row["Category"]));
				}

				MessageBox.Show("Emails are UIC emails and passwords are first name followed by 'CS480'. Ex: vmody2@uic.edu, VirenCS480");

				//txtEmail.Text = "vmody2@uic.edu";
				//txtPassword.Text = "VirenCS480";

			}
			catch (SqlException ex)
			{
				MessageBox.Show(string.Format("SQL Exception: {0}", ex.Message));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				if (db != null && db.State == ConnectionState.Open)
					db.Close();
			}

		}

		private void cmdLogin_Click(object sender, EventArgs e)
		{
			lstGroupExpenses.Items.Clear();
			lstGroups.Items.Clear();
			
			SqlConnection db = null;
			string sql;

			try
			{

				//
				// Check that login info has been entered
				// and store the email and password
				//
				if (String.IsNullOrWhiteSpace(txtEmail.Text))
				{
					MessageBox.Show("Please enter in your email address!");
					return;
				}
				if (String.IsNullOrWhiteSpace(txtPassword.Text))
				{
					MessageBox.Show("Please enter in your password!");
					return;
				}
				string email = txtEmail.Text;
				string inputPassword = txtPassword.Text;

				//
				// Check login information
				// 1) If given email's password is null? User doesn't exist.
				// 2) Else compare passwords.
				// 3) If they don't match print error message, else login and load data.
				//

				db = new SqlConnection(connectionInfo);
				db.Open();

				sql = string.Format(@"
SELECT Password
FROM Users
WHERE Email = '{0}';
", email);

				object result = ExecuteScalarQuery(db, sql);

				// Email does not exist in the system
				if (result == null)
				{
					MessageBox.Show("Your email and/or password doesn't match with our records!");
					return;
				}

				// Password is incorrect
				string realPassword = Convert.ToString(result);
				if (inputPassword != realPassword)
				{
					MessageBox.Show("Your email and/or password doesn't match with our records!");
					return;
				}

				// 
				// Email and Password are correct
				// Load groups associated with that email
				//

				sql = string.Format(@"
SELECT Temp.Name, SUM(NumResponsibleFor) as 'NumPeople'
FROM GroupUsers
INNER JOIN
(
	SELECT Groups.GroupID, Groups.Name
	FROM Groups
	INNER JOIN GroupUsers
	ON Groups.GroupID = GroupUsers.GroupID
	INNER JOIN Users
	ON GroupUsers.UserID = Users.UserID
	WHERE Email = '{0}'
) as Temp
ON GroupUsers.GroupID = Temp.GroupID
GROUP BY Temp.Name;
", email);

				DataSet ds = ExecuteNonScalarQuery(db, sql);
				//SqlDataAdapter adapter = new SqlDataAdapter(cmd);
				//cmd.CommandText = sql;

				//DataSet ds = new DataSet();
				//adapter.Fill(ds);
				//MessageBox.Show("Made It Here!");

				foreach (DataRow row in ds.Tables["TABLE"].Rows)
				{
					string groupName = string.Format("{0}: {1} Member(s)",
														Convert.ToString(row["Name"]),
														Convert.ToInt32(row["NumPeople"]));
					this.lstGroups.Items.Add(groupName);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				if (db != null && db.State == ConnectionState.Open)
					db.Close();
			}
			login = txtEmail.Text;
		}

		private void lstGroups_SelectedIndexChanged(object sender, EventArgs e)
		{
			// Nothing selected
			if (lstGroups.SelectedIndex < 0)
				return;

			// Clear out items in members and expenses list boxes
			lstMembers.Items.Clear();
			lstGroupExpenses.Items.Clear();

			SqlConnection db = null;
			string sql;

			try
			{
				// Get the selected group and pull out name
				string selection = this.lstGroups.SelectedItem.ToString();
				int pos = selection.IndexOf(':');
				string groupName = (selection.Substring(0, pos));

				// Add Group Name to expense details
				txtGroupName.Text = groupName;
				
				//
				// Load member list, expenses list, and total expenses for chosen group
				//

				db = new SqlConnection(connectionInfo);
				db.Open();

				sql = string.Format(@"
SELECT Email, FirstName, LastName, NumResponsibleFor
FROM Users
INNER JOIN GroupUsers
ON Users.UserID = GroupUsers.UserID
INNER JOIN Groups
ON GroupUsers.GroupID = Groups.GroupID
WHERE Groups.Name = '{0}';

SELECT ExpenseID, FirstName, LastName, Category, Cost, Date
FROM ExpenseHistory
INNER JOIN Groups
ON ExpenseHistory.GroupID = Groups.GroupID
INNER JOIN ExpenseCategories
ON ExpenseHistory.CategoryID = ExpenseCategories.CategoryID
INNER JOIN Users
ON ExpenseHistory.UserID = Users.UserID
WHERE Groups.Name = '{0}';

SELECT CAST(SUM(Cost) as DECIMAL(9,2)) as 'GroupTotalExpense'
FROM ExpenseHistory
INNER JOIN Groups
ON ExpenseHistory.GroupID = Groups.GroupID
WHERE Groups.Name = '{0}';
", groupName);

				DataSet ds = ExecuteNonScalarQuery(db, sql);
				//SqlDataAdapter adapter = new SqlDataAdapter(cmd);
				//cmd.CommandText = sql;

				//DataSet ds = new DataSet();
				//adapter.Fill(ds);
				//MessageBox.Show("Made It Here!");

				foreach (DataRow row in ds.Tables["TABLE"].Rows)
				{
					string member = string.Format("{0}: {1} {2}: Responsible For: {3} People",
														Convert.ToString(row["Email"]),
														Convert.ToString(row["FirstName"]),
														Convert.ToString(row["LastName"]),
														Convert.ToInt32(row["NumResponsibleFor"]));
					this.lstMembers.Items.Add(member);

					this.lstUserEmails.Items.Add(Convert.ToString(row["Email"]));
				}

				foreach (DataRow row in ds.Tables["TABLE1"].Rows)
				{
					string expense = string.Format("{0}: {1} {2}: {3}: ${4} on {5}",
														Convert.ToInt32(row["ExpenseID"]),
														Convert.ToString(row["FirstName"]),
														Convert.ToString(row["LastName"]),
														Convert.ToString(row["Category"]),
														Convert.ToDouble(row["Cost"]),
														(Convert.ToDateTime(row["Date"])).ToShortDateString());
					this.lstGroupExpenses.Items.Add(expense);
				}

				//
				// Display Group's total expenses
				//
				DataRow totalExpense = ds.Tables["TABLE2"].Rows[0];
				string total = Convert.ToString(totalExpense["GroupTotalExpense"]);
				if (String.IsNullOrWhiteSpace(total))
					txtGroupTotalExpense.Text = "$0.00";
				else
					txtGroupTotalExpense.Text = string.Format("${0}", total);


			}
			catch(SqlException ex)
			{
				MessageBox.Show(string.Format("SQL Exception: {0}", ex.Message));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				if (db != null && db.State == ConnectionState.Open)
					db.Close();
			}
			login = txtEmail.Text;
		}

		private void lstGroupExpenses_SelectedIndexChanged(object sender, EventArgs e)
		{
			// Nothing selected
			if (lstGroupExpenses.SelectedIndex < 0)
				return;

			SqlConnection db = null;
			string sql;

			try
			{
				// Get the selected expense and pull out the expense id
				string selection = this.lstGroupExpenses.SelectedItem.ToString();
				int pos = selection.IndexOf(':');
				string eid = (selection.Substring(0, pos));

				//
				// Load expense details
				//

				db = new SqlConnection(connectionInfo);
				db.Open();

				sql = string.Format(@"
SELECT ExpenseID, Email, Name AS 'GroupName', Category, Cost, Description, Date
FROM ExpenseHistory
INNER JOIN Groups
ON ExpenseHistory.GroupID = Groups.GroupID
INNER JOIN Users
ON ExpenseHistory.UserID = Users.UserID
INNER JOIN ExpenseCategories
ON ExpenseHistory.CategoryID = ExpenseCategories.CategoryID
WHERE ExpenseID = {0};
", eid);

				DataSet ds = ExecuteNonScalarQuery(db, sql);
				DataRow expense = ds.Tables["TABLE"].Rows[0];

				txtExpenseID.Text = Convert.ToString(expense["ExpenseID"]);
				lstUserEmails.Text = Convert.ToString(expense["Email"]);
				txtGroupName.Text = Convert.ToString(expense["GroupName"]);
				lstCategories.Text = Convert.ToString(expense["Category"]);
				txtCost.Text = string.Format("{0}", Convert.ToDouble(expense["Cost"]));
				txtDescription.Text = Convert.ToString(expense["Description"]);
				txtDate.Text = Convert.ToDateTime(expense["Date"]).ToShortDateString();

			}
			catch (SqlException ex)
			{
				MessageBox.Show(string.Format("SQL Exception: {0}", ex.Message));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				if (db != null && db.State == ConnectionState.Open)
					db.Close();
			}
		}

		private void cmdAddExpense_Click(object sender, EventArgs e)
		{
			//
			// Check all data boxes for sufficient information
			//
			if (String.IsNullOrWhiteSpace(lstUserEmails.Text) || String.IsNullOrWhiteSpace(txtGroupName.Text) 
						|| String.IsNullOrWhiteSpace(lstCategories.Text) || String.IsNullOrWhiteSpace(txtCost.Text) 
						|| String.IsNullOrWhiteSpace(txtDate.Text))
			{
				MessageBox.Show("Error: Please fill out all * fields to add an expense!");
				return;
			}

			//
			// Add/Insert New Expense
			//

			SqlConnection db = null;

			try
			{
				// Retrieve expense details from UI
				string email = lstUserEmails.Text;
				string groupname = txtGroupName.Text;
				string category = lstCategories.Text;
				double cost = Convert.ToDouble(txtCost.Text);
				string description = txtDescription.Text;
				string date = txtDate.Text;

				db = new SqlConnection(connectionInfo);
				db.Open();

				
				SqlCommand cmd = new SqlCommand();
				cmd.Connection = db;

				// Prepare and Call Stored Procedure
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.CommandText = "AddExpense";

				SqlParameter emailParam = cmd.Parameters.Add("email", SqlDbType.NVarChar);
				SqlParameter groupnameParam = cmd.Parameters.Add("groupname", SqlDbType.NVarChar);
				SqlParameter categoryParam = cmd.Parameters.Add("category", SqlDbType.NVarChar);
				SqlParameter costParam = cmd.Parameters.Add("cost", SqlDbType.Decimal);
				SqlParameter descParam = cmd.Parameters.Add("description", SqlDbType.NVarChar);
				SqlParameter dateParam = cmd.Parameters.Add("date", SqlDbType.Date);
				SqlParameter retval = cmd.Parameters.Add("RetVal", SqlDbType.Int);

				emailParam.Direction = ParameterDirection.Input;
				emailParam.Value = email;
				groupnameParam.Direction = ParameterDirection.Input;
				groupnameParam.Value = groupname;
				categoryParam.Direction = ParameterDirection.Input;
				categoryParam.Value = category;
				costParam.Direction = ParameterDirection.Input;
				costParam.Value = cost;
				descParam.Direction = ParameterDirection.Input;
				descParam.Value = description;
				dateParam.Direction = ParameterDirection.Input;
				dateParam.Value = date;
				retval.Direction = ParameterDirection.ReturnValue;

				object result = cmd.ExecuteScalar();
				int returnval = Convert.ToInt32(retval.Value);

				// If retval is -1: email DNE, -2: groupname DNE
				//		-3: category DNE, -4: Some SQL Error
				if (returnval == -1)
					throw new ApplicationException("Email does not exist in our records!");
				if (returnval == -2)
					throw new ApplicationException("Group Name does not exist in our records!");
				if (returnval == -3)
					throw new ApplicationException("Category does not exist in our records!");
				if (returnval == -4)
					throw new ApplicationException("Add expense failed!");

				MessageBox.Show("Expense added!");

				// Refresh group expenses to refresh expenses
				int selectedGroup = lstGroups.SelectedIndex;
				lstGroups.SelectedIndex = -1;
				lstGroups.SelectedIndex = selectedGroup;
					
			}
			catch (SqlException ex)
			{
				MessageBox.Show(string.Format("SqlException: {0}", ex.Message));
			}
			catch(Exception ex)
			{
				MessageBox.Show(string.Format("Exception: {0}", ex.Message));
			}
			finally
			{
				if (db != null && db.State == ConnectionState.Open)
					db.Close();
			}
		}

		private void cmdDeleteExpense_Click(object sender, EventArgs e)
		{
			// Nothing selected
			if (lstGroupExpenses.SelectedIndex < 0)
			{
				MessageBox.Show("ERROR: Please select an expense to delete first!");
				return;
			}

			//
			// Delete Expense
			//

			SqlConnection db = null;

			try
			{
				// Retrieve expense id from group expense list
				string selection = this.lstGroupExpenses.SelectedItem.ToString();
				int pos = selection.IndexOf(':');
				int eid = Convert.ToInt32((selection.Substring(0, pos)));

				db = new SqlConnection(connectionInfo);
				db.Open();

				SqlCommand cmd = new SqlCommand();
				cmd.Connection = db;

				// Prepare and Call Stored Procedure
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.CommandText = "DeleteExpense";

				SqlParameter eidParam = cmd.Parameters.Add("eid", SqlDbType.Int);
				SqlParameter retval = cmd.Parameters.Add("RetVal", SqlDbType.Int);

				eidParam.Direction = ParameterDirection.Input;
				eidParam.Value = eid;
				retval.Direction = ParameterDirection.ReturnValue;

				object result = cmd.ExecuteScalar();
				int returnval = Convert.ToInt32(retval.Value);

				// If retval is -1: expense DNE because it was already deleted
				//		-2: Some SQL Error
				if (returnval == -1)
					throw new ApplicationException("Expense already deleted, cannot delete again!");
				if (returnval == -2)
					throw new ApplicationException("Delete expense failed!");

				MessageBox.Show("Expense deleted!");

				// Refresh group expenses to refresh expenses
				int selectedGroup = lstGroups.SelectedIndex;
				lstGroups.SelectedIndex = -1;
				lstGroups.SelectedIndex = selectedGroup;

			}
			catch (SqlException ex)
			{
				MessageBox.Show(string.Format("SqlException: {0}", ex.Message));
			}
			catch (Exception ex)
			{
				MessageBox.Show(string.Format("Exception: {0}", ex.Message));
			}
			finally
			{
				if (db != null && db.State == ConnectionState.Open)
					db.Close();
			}
		}

		private void cmdUpdateExpense_Click(object sender, EventArgs e)
		{

		}

		private void cmdAddGroup_Click(object sender, EventArgs e)
		{
			// Check to see if user has logged in
			if(string.IsNullOrWhiteSpace(login))
			{
				MessageBox.Show("ERROR: Please login first in order to add groups to your account!");
				return;
			}

			Form2 addGroupForm = new Form2();
			if(addGroupForm.ShowDialog(this) == DialogResult.OK)
			{
				addGroupForm.Close();
				addGroupForm.Dispose();
				//MessageBox.Show("Group Added!");

				ClearExpenseDetailsUI();

				// Clear Group Expenses
				lstGroupExpenses.Items.Clear();
				lstGroupExpenses.Refresh();

				// Clear Members
				lstMembers.Items.Clear();
				lstMembers.Items.Clear();

				// Refresh group list
				lstGroups.SelectedIndex = -1;
				cmdLogin.PerformClick();
			}
		}

		private void cmdAddMember_Click(object sender, EventArgs e)
		{
			// Check to see if user has picked a group to add the member to
			// Nothing selected
			if (lstGroups.SelectedIndex < 0)
			{
				MessageBox.Show("ERROR: Please select a group in which to add the new member!");
				return;
			}

			Form3 addMemberForm = new Form3(getGroupName());
			if (addMemberForm.ShowDialog(this) == DialogResult.OK)
			{
				addMemberForm.Close();
				addMemberForm.Dispose();
				//MessageBox.Show("Member Added!");
			}

			// Clear Members
			lstMembers.Items.Clear();
			lstMembers.Items.Clear();

			// Refresh group expenses to refresh expenses
			int selectedGroup = lstGroups.SelectedIndex;
			lstGroups.SelectedIndex = -1;
			lstGroups.SelectedIndex = selectedGroup;
		}

		private void cmdEvenSplit_Click(object sender, EventArgs e)
		{
			// Check to see if user has picked a group
			// Nothing selected
			if (lstGroups.SelectedIndex < 0)
			{
				MessageBox.Show("ERROR: Please select a group first before calculating the even split!");
				return;
			}

			Form4 evenSplitForm = new Form4(getGroupName());

			if (evenSplitForm.ShowDialog(this) == DialogResult.OK)
			{
				evenSplitForm.Close();
				evenSplitForm.Dispose();
			}
		}
	}
}
