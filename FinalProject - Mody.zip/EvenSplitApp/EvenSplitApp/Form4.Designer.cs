﻿namespace EvenSplitApp
{
	partial class Form4
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
			this.lblGroupName = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.cmdExit = new System.Windows.Forms.Button();
			this.lstEvenSplit = new System.Windows.Forms.ListBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtNumberGroupMembers = new System.Windows.Forms.TextBox();
			this.txtGroupTotalExpense = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtCostPerPerson = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lblGroupName
			// 
			this.lblGroupName.AutoSize = true;
			this.lblGroupName.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblGroupName.Location = new System.Drawing.Point(177, 56);
			this.lblGroupName.Name = "lblGroupName";
			this.lblGroupName.Size = new System.Drawing.Size(101, 19);
			this.lblGroupName.TabIndex = 0;
			this.lblGroupName.Text = "GroupName";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Ravie", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Chartreuse;
			this.label1.Location = new System.Drawing.Point(144, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(185, 36);
			this.label1.TabIndex = 1;
			this.label1.Text = "Even$plit";
			// 
			// cmdExit
			// 
			this.cmdExit.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmdExit.Location = new System.Drawing.Point(161, 452);
			this.cmdExit.Name = "cmdExit";
			this.cmdExit.Size = new System.Drawing.Size(91, 31);
			this.cmdExit.TabIndex = 2;
			this.cmdExit.Text = "Done";
			this.cmdExit.UseVisualStyleBackColor = true;
			this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
			// 
			// lstEvenSplit
			// 
			this.lstEvenSplit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lstEvenSplit.FormattingEnabled = true;
			this.lstEvenSplit.ItemHeight = 19;
			this.lstEvenSplit.Location = new System.Drawing.Point(37, 190);
			this.lstEvenSplit.Name = "lstEvenSplit";
			this.lstEvenSplit.Size = new System.Drawing.Size(359, 232);
			this.lstEvenSplit.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(66, 92);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(168, 16);
			this.label2.TabIndex = 4;
			this.label2.Text = "Number of Group Members:";
			// 
			// txtNumberGroupMembers
			// 
			this.txtNumberGroupMembers.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtNumberGroupMembers.Location = new System.Drawing.Point(255, 89);
			this.txtNumberGroupMembers.Name = "txtNumberGroupMembers";
			this.txtNumberGroupMembers.Size = new System.Drawing.Size(121, 22);
			this.txtNumberGroupMembers.TabIndex = 5;
			// 
			// txtGroupTotalExpense
			// 
			this.txtGroupTotalExpense.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtGroupTotalExpense.Location = new System.Drawing.Point(255, 117);
			this.txtGroupTotalExpense.Name = "txtGroupTotalExpense";
			this.txtGroupTotalExpense.Size = new System.Drawing.Size(121, 22);
			this.txtGroupTotalExpense.TabIndex = 7;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(66, 120);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(142, 16);
			this.label3.TabIndex = 6;
			this.label3.Text = "Group\'s Total Expense:";
			// 
			// txtCostPerPerson
			// 
			this.txtCostPerPerson.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtCostPerPerson.Location = new System.Drawing.Point(255, 145);
			this.txtCostPerPerson.Name = "txtCostPerPerson";
			this.txtCostPerPerson.Size = new System.Drawing.Size(121, 22);
			this.txtCostPerPerson.TabIndex = 9;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(66, 148);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(182, 16);
			this.label4.TabIndex = 8;
			this.label4.Text = "Overall Total Cost Per Person:";
			// 
			// Form4
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.AppWorkspace;
			this.ClientSize = new System.Drawing.Size(435, 495);
			this.Controls.Add(this.txtCostPerPerson);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.txtGroupTotalExpense);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtNumberGroupMembers);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.lstEvenSplit);
			this.Controls.Add(this.cmdExit);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lblGroupName);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Form4";
			this.Text = "Even$plit";
			this.Load += new System.EventHandler(this.Form4_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblGroupName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button cmdExit;
		private System.Windows.Forms.ListBox lstEvenSplit;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtNumberGroupMembers;
		private System.Windows.Forms.TextBox txtGroupTotalExpense;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtCostPerPerson;
		private System.Windows.Forms.Label label4;
	}
}