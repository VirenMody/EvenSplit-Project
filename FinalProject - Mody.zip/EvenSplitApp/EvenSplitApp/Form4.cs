﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data.SqlClient;

namespace EvenSplitApp
{
	public partial class Form4 : Form
	{
		string groupName;

		public Form4(string groupname)
		{
			InitializeComponent();
			groupName = groupname;
		}

		private void Form4_Load(object sender, EventArgs e)
		{
			lblGroupName.Text = groupName;

			SqlConnection db = null;
			SqlTransaction tx = null;
			string sql;

			try
			{

				//
				// Load Group Expense Details 
				// and Even Split Details
				//

				db = new SqlConnection(Form1.connectionInfo);
				db.Open();
				tx = db.BeginTransaction(IsolationLevel.ReadCommitted);

				sql = string.Format(@"
DECLARE @grouptotalexpense AS DECIMAL(9,2);
DECLARE @groupnumpeople AS INT;

SELECT @grouptotalexpense = SUM(Cost) -- as 'GroupTotalExpense'
FROM ExpenseHistory
INNER JOIN Groups
ON ExpenseHistory.GroupID = Groups.GroupID
WHERE Groups.Name = '{0}';

SELECT @groupnumpeople = SUM(NumResponsibleFor)
FROM GroupUsers
INNER JOIN Groups
ON GroupUsers.GroupID = Groups.GroupID
WHERE Name = '{0}';

SELECT @grouptotalexpense as 'TotalExpense', 
			 @groupnumpeople	as 'NumberGroupMembers',
 			 CAST(ROUND(@grouptotalexpense/@groupnumpeople, 2) AS DECIMAL(9,2)) 'ExpensePerPerson'


SELECT Users.UserID, FirstName, LastName, Email, 
			 SUM(Cost) as 'UserExpense',
			 NumResponsibleFor,
			 --CAST(ROUND(SUM(Cost)/@groupnumpeople, 2) as DECIMAL(9,2))*NumResponsibleFor as 'CostPerGroupTheyOweThemselves',
			 --SUM(Cost)-CAST(ROUND(SUM(Cost)/@groupnumpeople, 2) as DECIMAL(9,2))*NumResponsibleFor as 'ToBePaidForTheirExpenses',
			 CAST(ROUND(@grouptotalexpense/@groupnumpeople, 2) AS DECIMAL(9,2))*NumResponsibleFor as 'OverallTotalCostPerUser',
			 (CAST(ROUND(@grouptotalexpense/@groupnumpeople, 2) AS DECIMAL(9,2))*NumResponsibleFor) - SUM(Cost) as 'Owe'
FROM Users
INNER JOIN GroupUsers
ON Users.UserID = GroupUsers.UserID
INNER JOIN Groups
ON GroupUsers.GroupID = Groups.GroupID
INNER JOIN ExpenseHistory
ON Users.UserID = ExpenseHistory.UserID
WHERE Name = '{0}'
GROUP BY Users.UserID, FirstName, LastName, Email, NumResponsibleFor
ORDER BY Email ASC;
", groupName);

				SqlCommand cmd = new SqlCommand();
				cmd.Connection = db;
				cmd.CommandText = sql;
				cmd.Transaction = tx;

				SqlDataAdapter adapter = new SqlDataAdapter(cmd);
				DataSet ds = new DataSet();
			
				adapter.Fill(ds);

				// Retrieve General Group Data from first table
				DataRow genData = ds.Tables["TABLE"].Rows[0];
				double totalExpense = Convert.ToDouble(genData["TotalExpense"]);
				int numGroupMembers = Convert.ToInt32(genData["NumberGroupMembers"]);
				double expPerPerson = Convert.ToDouble(genData["ExpensePerPerson"]);

				txtNumberGroupMembers.Text = Convert.ToString(numGroupMembers);
				txtGroupTotalExpense.Text = string.Format("${0:N2}", Convert.ToString(totalExpense));
				txtCostPerPerson.Text = string.Format("${0:N2}", Convert.ToString(expPerPerson));

				foreach (DataRow row in ds.Tables["TABLE1"].Rows)
				{
					string msg;
					msg = string.Format("{0} {1}: {2}:", Convert.ToString(row["FirstName"]), Convert.ToString(row["LastName"]), Convert.ToString(row["Email"]));
					this.lstEvenSplit.Items.Add(msg);
					msg = string.Format("    Number of People Responsible For: {0}", Convert.ToString(row["NumResponsibleFor"]));
					this.lstEvenSplit.Items.Add(msg);
					msg = string.Format("    User Spent: ${0:N2}", Convert.ToString(row["UserExpense"]));
					this.lstEvenSplit.Items.Add(msg);
					msg = string.Format("    Overall Total Cost for User: ${0:N2}", Convert.ToString(row["OverallTotalCostPerUser"]));
					this.lstEvenSplit.Items.Add(msg);

					// Determine if the user owes or is owed money
					double owe = Convert.ToDouble(row["Owe"]);
					if (owe < 0.0)
					{
						owe *= -1;
						msg = string.Format("    Is owed: ${0:N2}", owe);
					}
					else
					{
						msg = string.Format("    Owes: ${0:N2}", owe);
					}
					this.lstEvenSplit.Items.Add(msg);
					this.lstEvenSplit.Items.Add("");
				}

				tx.Commit();
			}
			catch (SqlException ex)
			{
				tx.Rollback();
				MessageBox.Show(string.Format("SQL Exception: {0}", ex.Message));
			}
			catch (Exception ex)
			{
				tx.Rollback();
				MessageBox.Show(ex.Message);
			}
			finally
			{
				if (db != null && db.State == ConnectionState.Open)
					db.Close();
			}
		}

		private void cmdExit_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
