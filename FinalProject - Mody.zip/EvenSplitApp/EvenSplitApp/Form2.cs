﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data.SqlClient;

namespace EvenSplitApp
{
	public partial class Form2 : Form
	{
		public Form2()
		{
			InitializeComponent();
			cmdAddGroup.DialogResult = DialogResult.OK;

		}

		private void cmdAddGroup_Click(object sender, EventArgs e)
		{
			// Check if a group name was entered
			if (string.IsNullOrWhiteSpace(txtAddGroup.Text) || string.IsNullOrWhiteSpace(txtNumPeopleResponsibleFor.Text))
			{
				MessageBox.Show("Please enter in all info!");
				return;
			}
			
			//
			// Add Group
			//

			SqlConnection db = null;
			string groupname = txtAddGroup.Text;
			int numPeople = Convert.ToInt32(txtNumPeopleResponsibleFor.Text);

			try
			{
				if(numPeople <= 0)
				{
					MessageBox.Show("Please enter a number greater than 0!");
					return;
				}

				db = new SqlConnection(Form1.connectionInfo);
				db.Open();

				SqlCommand cmd = new SqlCommand();
				cmd.Connection = db;

				// Prepare and Call Stored Procedure
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.CommandText = "AddGroup";

				SqlParameter groupNameParam = cmd.Parameters.Add("groupname", SqlDbType.NVarChar);
				SqlParameter emailParam = cmd.Parameters.Add("email", SqlDbType.NVarChar);
				SqlParameter numPeopleParam = cmd.Parameters.Add("numpeople", SqlDbType.Int);
				SqlParameter retval = cmd.Parameters.Add("RetVal", SqlDbType.Int);

				groupNameParam.Direction = ParameterDirection.Input;
				groupNameParam.Value = groupname;
				emailParam.Direction = ParameterDirection.Input;
				emailParam.Value = Form1.login;
				numPeopleParam.Direction = ParameterDirection.Input;
				numPeopleParam.Value = numPeople;
				retval.Direction = ParameterDirection.ReturnValue;

				object result = cmd.ExecuteScalar();
				int returnval = Convert.ToInt32(retval.Value);

				// If retval is -1: email DNE; -2: group name already exists for that user
				//	-3: Some SQL Error
				if (returnval == -1)
					throw new ApplicationException("Email does not exist in our records!");
				if (returnval == -2)
					throw new ApplicationException("Group Name already exists for this user!");
				if (returnval == -3)
					throw new ApplicationException("Delete expense failed!");

				MessageBox.Show("Group Added!");

			}
			catch (SqlException ex)
			{
				MessageBox.Show(string.Format("SqlException: {0}", ex.Message));
			}
			catch (Exception ex)
			{
				MessageBox.Show(string.Format("Exception: {0}", ex.Message));
			}
			finally
			{
				if (db != null && db.State == ConnectionState.Open)
					db.Close();
			}
		}
	}
}
