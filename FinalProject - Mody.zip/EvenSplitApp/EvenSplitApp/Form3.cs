﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Data.SqlClient;

namespace EvenSplitApp
{
	public partial class Form3 : Form
	{
		string groupName;

		public Form3(string groupname)
		{
			groupName = groupname;
			InitializeComponent();
		}

		private void Form3_Load(object sender, EventArgs e)
		{
			SqlConnection db = null;
			string sql;

			try
			{
				//
				// Load email/members list
				//

				db = new SqlConnection(Form1.connectionInfo);
				db.Open();

				sql = string.Format(@"
SELECT Email
FROM Users
");
				DataSet ds = Form1.ExecuteNonScalarQuery(db, sql);

				foreach (DataRow row in ds.Tables["TABLE"].Rows)
				{
					this.lstMemberEmails.Items.Add(Convert.ToString(row["Email"]));
				}

			}
			catch (SqlException ex)
			{
				MessageBox.Show(string.Format("SQL Exception: {0}", ex.Message));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				if (db != null && db.State == ConnectionState.Open)
					db.Close();
			}

		}

		private void cmdAddMember_Click(object sender, EventArgs e)
		{
			// Check if a user email was selected and number of people responsible for was entered
			if (string.IsNullOrWhiteSpace(lstMemberEmails.Text) || string.IsNullOrWhiteSpace(txtNumPeopleResponsibleFor.Text))
			{
				MessageBox.Show("Please enter in all info!");
				return;
			}

			//
			// Add Member
			//

			SqlConnection db = null;
			string email = lstMemberEmails.SelectedItem.ToString();
			int numPeople = Convert.ToInt32(txtNumPeopleResponsibleFor.Text);

			try
			{
				if (numPeople <= 0)
				{
					MessageBox.Show("Please enter a number greater than 0!");
					return;
				}

				db = new SqlConnection(Form1.connectionInfo);
				db.Open();

				SqlCommand cmd = new SqlCommand();
				cmd.Connection = db;

				// Prepare and Call Stored Procedure
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.CommandText = "AddMember";

				SqlParameter groupNameParam = cmd.Parameters.Add("groupname", SqlDbType.NVarChar);
				SqlParameter emailParam = cmd.Parameters.Add("email", SqlDbType.NVarChar);
				SqlParameter numPeopleParam = cmd.Parameters.Add("membernumpeople", SqlDbType.Int);
				SqlParameter retval = cmd.Parameters.Add("RetVal", SqlDbType.Int);

				groupNameParam.Direction = ParameterDirection.Input;
				groupNameParam.Value = groupName;
				emailParam.Direction = ParameterDirection.Input;
				emailParam.Value = email;
				numPeopleParam.Direction = ParameterDirection.Input;
				numPeopleParam.Value = numPeople;
				retval.Direction = ParameterDirection.ReturnValue;

				object result = cmd.ExecuteScalar();
				int returnval = Convert.ToInt32(retval.Value);

				// If retval is -1: email DNE; -2: user already exists in group
				//	-3: Some SQL Error
				if (returnval == -1)
					throw new ApplicationException("Email does not exist in our records!");
				if (returnval == -2)
					throw new ApplicationException("Email already exists in this group!");
				if (returnval == -3)
					throw new ApplicationException("Adding Member failed!");

				MessageBox.Show("Member Added!");
				MessageBox.Show("Woohoo more people to split with! Wait...uh oh that means more expenses...");

				this.Close();
			}
			catch (SqlException ex)
			{
				MessageBox.Show(string.Format("SqlException: {0}", ex.Message));
			}
			catch (Exception ex)
			{
				MessageBox.Show(string.Format("Exception: {0}", ex.Message));
			}
			finally
			{
				if (db != null && db.State == ConnectionState.Open)
					db.Close();
			}
		}
	}
}
