﻿namespace EvenSplitApp
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.txtEmail = new System.Windows.Forms.TextBox();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.cmdLogin = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.lstGroups = new System.Windows.Forms.ListBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.lstMembers = new System.Windows.Forms.ListBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.lstGroupExpenses = new System.Windows.Forms.ListBox();
			this.cmdDeleteExpense = new System.Windows.Forms.Button();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.txtCost = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.txtDescription = new System.Windows.Forms.TextBox();
			this.lstUserEmails = new System.Windows.Forms.ComboBox();
			this.lstCategories = new System.Windows.Forms.ComboBox();
			this.cmdAddExpense = new System.Windows.Forms.Button();
			this.label11 = new System.Windows.Forms.Label();
			this.txtExpenseID = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.txtGroupTotalExpense = new System.Windows.Forms.TextBox();
			this.txtGroupName = new System.Windows.Forms.TextBox();
			this.label13 = new System.Windows.Forms.Label();
			this.txtDate = new System.Windows.Forms.TextBox();
			this.cmdAddGroup = new System.Windows.Forms.Button();
			this.cmdAddMember = new System.Windows.Forms.Button();
			this.cmdEvenSplit = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtEmail
			// 
			this.txtEmail.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtEmail.Location = new System.Drawing.Point(12, 37);
			this.txtEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.txtEmail.Name = "txtEmail";
			this.txtEmail.Size = new System.Drawing.Size(311, 26);
			this.txtEmail.TabIndex = 2;
			// 
			// txtPassword
			// 
			this.txtPassword.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtPassword.Location = new System.Drawing.Point(12, 94);
			this.txtPassword.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.PasswordChar = '*';
			this.txtPassword.Size = new System.Drawing.Size(311, 26);
			this.txtPassword.TabIndex = 3;
			// 
			// cmdLogin
			// 
			this.cmdLogin.BackColor = System.Drawing.Color.SpringGreen;
			this.cmdLogin.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmdLogin.Location = new System.Drawing.Point(14, 132);
			this.cmdLogin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.cmdLogin.Name = "cmdLogin";
			this.cmdLogin.Size = new System.Drawing.Size(311, 34);
			this.cmdLogin.TabIndex = 4;
			this.cmdLogin.Text = "Log In";
			this.cmdLogin.UseVisualStyleBackColor = false;
			this.cmdLogin.Click += new System.EventHandler(this.cmdLogin_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(20, 196);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(66, 23);
			this.label1.TabIndex = 5;
			this.label1.Text = "Groups";
			// 
			// lstGroups
			// 
			this.lstGroups.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lstGroups.FormattingEnabled = true;
			this.lstGroups.HorizontalScrollbar = true;
			this.lstGroups.ItemHeight = 18;
			this.lstGroups.Location = new System.Drawing.Point(16, 231);
			this.lstGroups.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.lstGroups.Name = "lstGroups";
			this.lstGroups.Size = new System.Drawing.Size(308, 130);
			this.lstGroups.TabIndex = 6;
			this.lstGroups.SelectedIndexChanged += new System.EventHandler(this.lstGroups_SelectedIndexChanged);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(12, 10);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(66, 23);
			this.label2.TabIndex = 7;
			this.label2.Text = "Email:";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(12, 69);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(97, 23);
			this.label3.TabIndex = 8;
			this.label3.Text = "Password:";
			// 
			// lstMembers
			// 
			this.lstMembers.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lstMembers.FormattingEnabled = true;
			this.lstMembers.HorizontalScrollbar = true;
			this.lstMembers.ItemHeight = 18;
			this.lstMembers.Location = new System.Drawing.Point(14, 421);
			this.lstMembers.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.lstMembers.Name = "lstMembers";
			this.lstMembers.Size = new System.Drawing.Size(311, 148);
			this.lstMembers.TabIndex = 9;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(20, 390);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(85, 23);
			this.label4.TabIndex = 10;
			this.label4.Text = "Members";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(355, 7);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(184, 23);
			this.label5.TabIndex = 12;
			this.label5.Text = "Group Expense History";
			// 
			// lstGroupExpenses
			// 
			this.lstGroupExpenses.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lstGroupExpenses.FormattingEnabled = true;
			this.lstGroupExpenses.HorizontalScrollbar = true;
			this.lstGroupExpenses.ItemHeight = 18;
			this.lstGroupExpenses.Location = new System.Drawing.Point(359, 39);
			this.lstGroupExpenses.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.lstGroupExpenses.Name = "lstGroupExpenses";
			this.lstGroupExpenses.Size = new System.Drawing.Size(734, 256);
			this.lstGroupExpenses.TabIndex = 11;
			this.lstGroupExpenses.SelectedIndexChanged += new System.EventHandler(this.lstGroupExpenses_SelectedIndexChanged);
			// 
			// cmdDeleteExpense
			// 
			this.cmdDeleteExpense.BackColor = System.Drawing.Color.Crimson;
			this.cmdDeleteExpense.Font = new System.Drawing.Font("Georgia", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmdDeleteExpense.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.cmdDeleteExpense.Location = new System.Drawing.Point(827, 390);
			this.cmdDeleteExpense.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.cmdDeleteExpense.Name = "cmdDeleteExpense";
			this.cmdDeleteExpense.Size = new System.Drawing.Size(232, 78);
			this.cmdDeleteExpense.TabIndex = 13;
			this.cmdDeleteExpense.Text = "Delete Expense";
			this.cmdDeleteExpense.UseVisualStyleBackColor = false;
			this.cmdDeleteExpense.Click += new System.EventHandler(this.cmdDeleteExpense_Click);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(377, 350);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(110, 20);
			this.label6.TabIndex = 15;
			this.label6.Text = "User Email: *";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(364, 390);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(123, 20);
			this.label7.TabIndex = 17;
			this.label7.Text = "Group Name: *";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.Location = new System.Drawing.Point(396, 432);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(93, 20);
			this.label8.TabIndex = 19;
			this.label8.Text = "Category: *";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.Location = new System.Drawing.Point(428, 484);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(59, 20);
			this.label9.TabIndex = 21;
			this.label9.Text = "Cost: *";
			// 
			// txtCost
			// 
			this.txtCost.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtCost.Location = new System.Drawing.Point(492, 478);
			this.txtCost.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.txtCost.Name = "txtCost";
			this.txtCost.Size = new System.Drawing.Size(283, 26);
			this.txtCost.TabIndex = 20;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.Location = new System.Drawing.Point(376, 567);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(102, 20);
			this.label10.TabIndex = 23;
			this.label10.Text = "Description:";
			// 
			// txtDescription
			// 
			this.txtDescription.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtDescription.Location = new System.Drawing.Point(492, 561);
			this.txtDescription.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.txtDescription.Name = "txtDescription";
			this.txtDescription.Size = new System.Drawing.Size(283, 26);
			this.txtDescription.TabIndex = 22;
			// 
			// lstUserEmails
			// 
			this.lstUserEmails.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lstUserEmails.FormattingEnabled = true;
			this.lstUserEmails.Location = new System.Drawing.Point(492, 346);
			this.lstUserEmails.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.lstUserEmails.Name = "lstUserEmails";
			this.lstUserEmails.Size = new System.Drawing.Size(283, 26);
			this.lstUserEmails.TabIndex = 24;
			// 
			// lstCategories
			// 
			this.lstCategories.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lstCategories.FormattingEnabled = true;
			this.lstCategories.Location = new System.Drawing.Point(492, 430);
			this.lstCategories.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.lstCategories.Name = "lstCategories";
			this.lstCategories.Size = new System.Drawing.Size(283, 26);
			this.lstCategories.TabIndex = 26;
			// 
			// cmdAddExpense
			// 
			this.cmdAddExpense.BackColor = System.Drawing.Color.SpringGreen;
			this.cmdAddExpense.Font = new System.Drawing.Font("Georgia", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmdAddExpense.Location = new System.Drawing.Point(827, 303);
			this.cmdAddExpense.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.cmdAddExpense.Name = "cmdAddExpense";
			this.cmdAddExpense.Size = new System.Drawing.Size(232, 76);
			this.cmdAddExpense.TabIndex = 27;
			this.cmdAddExpense.Text = "Add Expense";
			this.cmdAddExpense.UseVisualStyleBackColor = false;
			this.cmdAddExpense.Click += new System.EventHandler(this.cmdAddExpense_Click);
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.Location = new System.Drawing.Point(377, 305);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(101, 20);
			this.label11.TabIndex = 30;
			this.label11.Text = "Expense ID:";
			// 
			// txtExpenseID
			// 
			this.txtExpenseID.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtExpenseID.Location = new System.Drawing.Point(492, 306);
			this.txtExpenseID.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.txtExpenseID.Name = "txtExpenseID";
			this.txtExpenseID.Size = new System.Drawing.Size(283, 26);
			this.txtExpenseID.TabIndex = 29;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Font = new System.Drawing.Font("Impact", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.Location = new System.Drawing.Point(676, 10);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(184, 23);
			this.label12.TabIndex = 31;
			this.label12.Text = "Group\'s Total Expense:";
			// 
			// txtGroupTotalExpense
			// 
			this.txtGroupTotalExpense.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtGroupTotalExpense.Location = new System.Drawing.Point(896, 10);
			this.txtGroupTotalExpense.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.txtGroupTotalExpense.Name = "txtGroupTotalExpense";
			this.txtGroupTotalExpense.Size = new System.Drawing.Size(182, 26);
			this.txtGroupTotalExpense.TabIndex = 32;
			// 
			// txtGroupName
			// 
			this.txtGroupName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtGroupName.Location = new System.Drawing.Point(492, 387);
			this.txtGroupName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.txtGroupName.Name = "txtGroupName";
			this.txtGroupName.Size = new System.Drawing.Size(283, 26);
			this.txtGroupName.TabIndex = 33;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Font = new System.Drawing.Font("Georgia", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.Location = new System.Drawing.Point(423, 524);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(62, 20);
			this.label13.TabIndex = 35;
			this.label13.Text = "Date: *";
			// 
			// txtDate
			// 
			this.txtDate.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.txtDate.Location = new System.Drawing.Point(492, 522);
			this.txtDate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.txtDate.Name = "txtDate";
			this.txtDate.Size = new System.Drawing.Size(283, 26);
			this.txtDate.TabIndex = 34;
			// 
			// cmdAddGroup
			// 
			this.cmdAddGroup.BackColor = System.Drawing.Color.SpringGreen;
			this.cmdAddGroup.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmdAddGroup.Location = new System.Drawing.Point(194, 188);
			this.cmdAddGroup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.cmdAddGroup.Name = "cmdAddGroup";
			this.cmdAddGroup.Size = new System.Drawing.Size(121, 36);
			this.cmdAddGroup.TabIndex = 36;
			this.cmdAddGroup.Text = "Add Group";
			this.cmdAddGroup.UseVisualStyleBackColor = false;
			this.cmdAddGroup.Click += new System.EventHandler(this.cmdAddGroup_Click);
			// 
			// cmdAddMember
			// 
			this.cmdAddMember.BackColor = System.Drawing.Color.SpringGreen;
			this.cmdAddMember.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmdAddMember.Location = new System.Drawing.Point(194, 376);
			this.cmdAddMember.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.cmdAddMember.Name = "cmdAddMember";
			this.cmdAddMember.Size = new System.Drawing.Size(121, 37);
			this.cmdAddMember.TabIndex = 37;
			this.cmdAddMember.Text = "Add Member";
			this.cmdAddMember.UseVisualStyleBackColor = false;
			this.cmdAddMember.Click += new System.EventHandler(this.cmdAddMember_Click);
			// 
			// cmdEvenSplit
			// 
			this.cmdEvenSplit.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.cmdEvenSplit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.cmdEvenSplit.Font = new System.Drawing.Font("Ravie", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmdEvenSplit.ForeColor = System.Drawing.Color.SpringGreen;
			this.cmdEvenSplit.Location = new System.Drawing.Point(827, 481);
			this.cmdEvenSplit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.cmdEvenSplit.Name = "cmdEvenSplit";
			this.cmdEvenSplit.Size = new System.Drawing.Size(232, 113);
			this.cmdEvenSplit.TabIndex = 38;
			this.cmdEvenSplit.Text = "Even $plit!";
			this.cmdEvenSplit.UseVisualStyleBackColor = false;
			this.cmdEvenSplit.Click += new System.EventHandler(this.cmdEvenSplit_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1108, 616);
			this.Controls.Add(this.cmdEvenSplit);
			this.Controls.Add(this.cmdAddMember);
			this.Controls.Add(this.cmdAddGroup);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.txtDate);
			this.Controls.Add(this.txtGroupName);
			this.Controls.Add(this.txtGroupTotalExpense);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.txtExpenseID);
			this.Controls.Add(this.cmdAddExpense);
			this.Controls.Add(this.lstCategories);
			this.Controls.Add(this.lstUserEmails);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.txtDescription);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.txtCost);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.cmdDeleteExpense);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.lstGroupExpenses);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.lstMembers);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.lstGroups);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.cmdLogin);
			this.Controls.Add(this.txtPassword);
			this.Controls.Add(this.txtEmail);
			this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.Name = "Form1";
			this.Text = "Even$plit";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtEmail;
		private System.Windows.Forms.TextBox txtPassword;
		private System.Windows.Forms.Button cmdLogin;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ListBox lstGroups;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ListBox lstMembers;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ListBox lstGroupExpenses;
		private System.Windows.Forms.Button cmdDeleteExpense;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox txtCost;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox txtDescription;
		private System.Windows.Forms.ComboBox lstUserEmails;
		private System.Windows.Forms.ComboBox lstCategories;
		private System.Windows.Forms.Button cmdAddExpense;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.TextBox txtExpenseID;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox txtGroupTotalExpense;
		private System.Windows.Forms.TextBox txtGroupName;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.TextBox txtDate;
		private System.Windows.Forms.Button cmdAddGroup;
		private System.Windows.Forms.Button cmdAddMember;
		private System.Windows.Forms.Button cmdEvenSplit;
	}
}

