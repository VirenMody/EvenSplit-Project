﻿namespace EvenSplitApp
{
	partial class Form2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
			this.label1 = new System.Windows.Forms.Label();
			this.txtAddGroup = new System.Windows.Forms.TextBox();
			this.cmdAddGroup = new System.Windows.Forms.Button();
			this.txtNumPeopleResponsibleFor = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(99, 15);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(94, 18);
			this.label1.TabIndex = 0;
			this.label1.Text = "Group Name";
			// 
			// txtAddGroup
			// 
			this.txtAddGroup.Location = new System.Drawing.Point(65, 45);
			this.txtAddGroup.Name = "txtAddGroup";
			this.txtAddGroup.Size = new System.Drawing.Size(173, 20);
			this.txtAddGroup.TabIndex = 1;
			// 
			// cmdAddGroup
			// 
			this.cmdAddGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmdAddGroup.Location = new System.Drawing.Point(88, 157);
			this.cmdAddGroup.Name = "cmdAddGroup";
			this.cmdAddGroup.Size = new System.Drawing.Size(111, 26);
			this.cmdAddGroup.TabIndex = 2;
			this.cmdAddGroup.Text = "Add Group";
			this.cmdAddGroup.UseVisualStyleBackColor = true;
			this.cmdAddGroup.Click += new System.EventHandler(this.cmdAddGroup_Click);
			// 
			// txtNumPeopleResponsibleFor
			// 
			this.txtNumPeopleResponsibleFor.Location = new System.Drawing.Point(115, 123);
			this.txtNumPeopleResponsibleFor.Name = "txtNumPeopleResponsibleFor";
			this.txtNumPeopleResponsibleFor.Size = new System.Drawing.Size(64, 20);
			this.txtNumPeopleResponsibleFor.TabIndex = 4;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(86, 79);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 18);
			this.label2.TabIndex = 3;
			this.label2.Text = "Number of People";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(54, 97);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(197, 18);
			this.label3.TabIndex = 5;
			this.label3.Text = "(that you are responsible for)";
			// 
			// Form2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(295, 203);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtNumPeopleResponsibleFor);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cmdAddGroup);
			this.Controls.Add(this.txtAddGroup);
			this.Controls.Add(this.label1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Form2";
			this.Text = "Even$plit: Add Group";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtAddGroup;
		private System.Windows.Forms.Button cmdAddGroup;
		private System.Windows.Forms.TextBox txtNumPeopleResponsibleFor;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
	}
}