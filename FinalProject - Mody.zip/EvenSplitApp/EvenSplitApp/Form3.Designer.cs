﻿namespace EvenSplitApp
{
	partial class Form3
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
			this.label3 = new System.Windows.Forms.Label();
			this.txtNumPeopleResponsibleFor = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.cmdAddMember = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.lstMemberEmails = new System.Windows.Forms.ComboBox();
			this.SuspendLayout();
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.Location = new System.Drawing.Point(44, 81);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(217, 18);
			this.label3.TabIndex = 11;
			this.label3.Text = "(this member is responsible for)";
			// 
			// txtNumPeopleResponsibleFor
			// 
			this.txtNumPeopleResponsibleFor.Location = new System.Drawing.Point(108, 102);
			this.txtNumPeopleResponsibleFor.Name = "txtNumPeopleResponsibleFor";
			this.txtNumPeopleResponsibleFor.Size = new System.Drawing.Size(64, 20);
			this.txtNumPeopleResponsibleFor.TabIndex = 10;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.Location = new System.Drawing.Point(85, 63);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(128, 18);
			this.label2.TabIndex = 9;
			this.label2.Text = "Number of People";
			// 
			// cmdAddMember
			// 
			this.cmdAddMember.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmdAddMember.Location = new System.Drawing.Point(88, 141);
			this.cmdAddMember.Name = "cmdAddMember";
			this.cmdAddMember.Size = new System.Drawing.Size(111, 26);
			this.cmdAddMember.TabIndex = 8;
			this.cmdAddMember.Text = "Add Member";
			this.cmdAddMember.UseVisualStyleBackColor = true;
			this.cmdAddMember.Click += new System.EventHandler(this.cmdAddMember_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(12, 29);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(45, 18);
			this.label1.TabIndex = 6;
			this.label1.Text = "Email";
			// 
			// lstMemberEmails
			// 
			this.lstMemberEmails.FormattingEnabled = true;
			this.lstMemberEmails.Location = new System.Drawing.Point(68, 26);
			this.lstMemberEmails.Name = "lstMemberEmails";
			this.lstMemberEmails.Size = new System.Drawing.Size(173, 21);
			this.lstMemberEmails.TabIndex = 12;
			// 
			// Form3
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(284, 184);
			this.Controls.Add(this.lstMemberEmails);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtNumPeopleResponsibleFor);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cmdAddMember);
			this.Controls.Add(this.label1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Form3";
			this.Text = "Even$plit: Add Member";
			this.Load += new System.EventHandler(this.Form3_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtNumPeopleResponsibleFor;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button cmdAddMember;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox lstMemberEmails;
	}
}