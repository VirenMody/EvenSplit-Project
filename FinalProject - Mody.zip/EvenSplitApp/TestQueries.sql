﻿--
-- LOGIN: Check correctness of login info
--
SELECT Password
FROM Users
WHERE Email = 'vmody2@uic.edu'

--
-- Load Groups associated with user email
--
SELECT Name, NumPeople
FROM Groups
INNER JOIN GroupUsers
ON Groups.GroupID = GroupUsers.GroupID
INNER JOIN Users
ON GroupUsers.UserID = Users.UserID
WHERE Email = 'vmody2@uic.edu';

--
-- Load members of the chosen group
--
SELECT Email, FirstName, LastName, GroupUsers.NumResponsibleFor
FROM Users
INNER JOIN GroupUsers
ON Users.UserID = GroupUsers.UserID
INNER JOIN Groups
ON GroupUsers.GroupID = Groups.GroupID
WHERE Groups.Name = 'Batch Meeting 2016';

--
-- Load expense list of the chosen group
--
SELECT ExpenseID, FirstName, LastName, Category, Cost, Date
FROM ExpenseHistory
INNER JOIN Groups
ON ExpenseHistory.GroupID = Groups.GroupID
INNER JOIN ExpenseCategories
ON ExpenseHistory.CategoryID = ExpenseCategories.CategoryID
INNER JOIN Users
ON ExpenseHistory.UserID = Users.UserID
WHERE Name = 'Batch Meeting 2016';

--
-- Delete a transaction
--
DECLARE @eid AS INT;

SELECT @eid = ExpenseID
FROM ExpenseHistory
WHERE ExpenseID = 3014;

IF @eid IS NULL		-- It doesn't exist (aka it's already deleted)
 RETURN -1;

DELETE FROM ExpenseHistory -- It exists and is ready to be deleted
WHERE ExpenseID = @eid;

RETURN 0;





SELECT ExpenseID, Email, Name AS 'GroupName', Category, Cost, Description, Date
FROM ExpenseHistory
INNER JOIN Groups
ON ExpenseHistory.GroupID = Groups.GroupID
INNER JOIN Users
ON ExpenseHistory.UserID = Users.UserID
INNER JOIN ExpenseCategories
ON ExpenseHistory.CategoryID = ExpenseCategories.CategoryID
WHERE ExpenseID = 30014;

SELECT * 
FROM ExpenseHistory
WHERE ExpenseID = 30014;



SELECT DISTINCT Email
FROM Users
INNER JOIN GroupUsers
ON Users.UserID = GroupUsers.UserID
INNER JOIN Groups
ON GroupUsers.GroupID = Groups.GroupID
WHERE Name <> 'Batch Meeting 2016'
ORDER BY Email;

SELECT *
FROM ExpenseHistory

DECLARE @grouptotalexpense AS DECIMAL(9,2);
DECLARE @groupnumpeople AS INT;

SELECT @grouptotalexpense = SUM(Cost) -- as 'GroupTotalExpense'
FROM ExpenseHistory
INNER JOIN Groups
ON ExpenseHistory.GroupID = Groups.GroupID
WHERE Groups.Name = 'Batch Meeting 2016';

SELECT @groupnumpeople = SUM(NumResponsibleFor)
FROM GroupUsers
INNER JOIN Groups
ON GroupUsers.GroupID = Groups.GroupID
WHERE Name = 'Batch Meeting 2016';

SELECT @grouptotalexpense as 'TotalExpense', 
			 @groupnumpeople	as 'TotalGroupMembers',
 			 CAST(ROUND(@grouptotalexpense/@groupnumpeople, 2) AS DECIMAL(9,2)) 'ExpensePerPerson'


SELECT Users.UserID, FirstName, LastName, Email, 
			 SUM(Cost) as 'UserExpense',
			 NumResponsibleFor,
			 --CAST(ROUND(SUM(Cost)/@groupnumpeople, 2) as DECIMAL(9,2))*NumResponsibleFor as 'CostPerGroupTheyOweThemselves',
			 --SUM(Cost)-CAST(ROUND(SUM(Cost)/@groupnumpeople, 2) as DECIMAL(9,2))*NumResponsibleFor as 'ToBePaidForTheirExpenses',
			 CAST(ROUND(@grouptotalexpense/@groupnumpeople, 2) AS DECIMAL(9,2))*NumResponsibleFor as 'OverallTotalCostPerGroup',
			 (CAST(ROUND(@grouptotalexpense/@groupnumpeople, 2) AS DECIMAL(9,2))*NumResponsibleFor) - SUM(Cost) as 'Owe'
FROM Users
INNER JOIN GroupUsers
ON Users.UserID = GroupUsers.UserID
INNER JOIN Groups
ON GroupUsers.GroupID = Groups.GroupID
INNER JOIN ExpenseHistory
ON Users.UserID = ExpenseHistory.UserID
WHERE Name = 'Batch Meeting 2016'
GROUP BY Users.UserID, FirstName, LastName, Email, NumResponsibleFor
ORDER BY Email ASC;

